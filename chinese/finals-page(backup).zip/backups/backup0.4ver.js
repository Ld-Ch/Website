const SUPABASE_URL = "https://uqcodazkoityuhhnbmum.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_WQwKJgTCh9fTaQV3dNWL-A_LrcipKPi";

const client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let posts = [];
let editorMode = false;
let activeEditId = null;

let isDraggingGlobal = false;
let suppressRender = false;

// -------------------------
// EDITOR TOGGLE (optional manual use)
// -------------------------
function toggleEditorMode() {
    editorMode = !editorMode;
    renderCanvas();
}

// -------------------------
// FINISH EDITING BUTTON
// -------------------------
function createFinishEditingButton(post) {
    const btn = document.createElement("button");
    btn.innerText = "Finish Editing";
    btn.style.marginTop = "6px";
    btn.style.padding = "4px 6px";
    btn.style.fontSize = "12px";
    btn.style.cursor = "pointer";

    btn.onclick = async () => {
        await client
            .from("posts")
            .update({ locked: true })
            .eq("id", post.id);

        post.locked = true;

        // exit edit mode
        if (activeEditId === post.id) {
            activeEditId = null;
            editorMode = false;
        }

        renderCanvas();
    };

    return btn;
}

// -------------------------
// RENDER SYSTEM
// -------------------------
function renderCanvas() {
    if (suppressRender) return;
    const canvas = document.getElementById("canvas");
    canvas.innerHTML = "";

    posts.forEach((post) => {

        const wrapper = document.createElement("div");
        wrapper.className = "post";

        wrapper.style.position = "absolute";
        wrapper.style.left = post.x + "px";
        wrapper.style.top = post.y + "px";

        // IMAGE
        const img = document.createElement("img");
        img.src = post.image_url;
        img.style.width = "150px";
        img.style.display = "block";
        img.style.userSelect = "none";
        img.style.cursor = post.locked ? "default" : "grab";

        wrapper.appendChild(img);

        // 🔥 MUST DEFINE THIS FIRST
        const isActiveEditor =
            editorMode &&
            !post.locked &&
            post.id === activeEditId;

        // INFO BOX
        const info = document.createElement("div");
        info.className = isActiveEditor ? "info info-active" : "info";

        // -------------------------
        // NOTE SYSTEM
        // -------------------------
        if (isActiveEditor) {
            const textarea = document.createElement("textarea");
            textarea.value = post.note || "";
            textarea.placeholder = "Write a note...";
            textarea.className = "note-input";

            textarea.style.width = "150px";
            textarea.style.marginTop = "6px";
            textarea.style.display = "block";

            textarea.addEventListener("input", async (e) => {
                const value = e.target.value;

                post.note = value;

                await client
                    .from("posts")
                    .update({ note: value })
                    .eq("id", post.id);
            });

            info.appendChild(textarea);
        } else if (post.note) {
            const note = document.createElement("div");
            note.className = "note";
            note.innerText = "📝 " + post.note;
            info.appendChild(note);
        }

        // TIMESTAMP
        const time = document.createElement("div");
        time.className = "time";
        time.innerText =
            "🕒 " + new Date(post.created_at).toLocaleString();

        info.appendChild(time);

        // BUTTON + DRAG ONLY IN ACTIVE EDIT MODE
        if (isActiveEditor) {
            const btn = createFinishEditingButton(post);
            info.appendChild(btn);

            enableDrag(wrapper, post.id);
        }

        wrapper.appendChild(info);
        canvas.appendChild(wrapper);
    });
}

// -------------------------
// LOAD POSTS (ALL LOCKED BY DEFAULT)
// -------------------------
async function loadPosts() {
    const { data, error } = await client
        .from("posts")
        .select("*")
        .order("created_at", { ascending: true });

    if (error) {
        console.log(error);
        return;
    }

    posts = data || [];

    // ensure locked default behavior
    posts.forEach(p => {
        if (p.locked === undefined || p.locked === null) {
            p.locked = true;
        }
    });

    renderCanvas();
}

// -------------------------
// UPLOAD CORE LOGIC
// -------------------------
async function handleUpload(file, x, y) {
    const fileName = `${Date.now()}-${file.name}`;

    await client.storage.from("Images").upload(fileName, file);

    const { data } = client.storage
        .from("Images")
        .getPublicUrl(fileName);

    const { data: inserted } = await client
        .from("posts")
        .insert([
            {
                image_url: data.publicUrl,
                x,
                y,
                locked: false,
                note: "",
                created_at: new Date().toISOString()
            }
        ])
        .select();

    // 🔥 ENTER EDIT MODE ONLY FOR NEW ITEM
    const newPost = inserted?.[0];

    if (newPost) {
        activeEditId = newPost.id;
        editorMode = true;
    }

    renderCanvas();
}

// -------------------------
// BACKUP FILE INPUT UPLOAD
// -------------------------
window.uploadImage = async function () {
    const file = document.getElementById("fileInput").files[0];
    if (!file) return alert("No file selected");

    await handleUpload(
        file,
        window.innerWidth / 2,
        window.innerHeight / 2
    );
};

// -------------------------
// DRAG & DROP
// -------------------------
document.addEventListener("dragover", (e) => e.preventDefault());

document.addEventListener("drop", async (e) => {
    e.preventDefault();

    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    await handleUpload(file, e.clientX, e.clientY);
});

// -------------------------
// DRAG MOVEMENT
// -------------------------
function enableDrag(el, id) {
    let offsetX = 0;
    let offsetY = 0;
    let isDragging = false;

    function onPointerDown(e) {
        if (e.target.tagName === "TEXTAREA" ||
            e.target.tagName === "INPUT" ||
            e.target.tagName === "BUTTON") return;

        isDragging = true;
        isDraggingGlobal = true; // 🔥 GLOBAL LOCK

        el.setPointerCapture(e.pointerId);

        offsetX = e.clientX - el.offsetLeft;
        offsetY = e.clientY - el.offsetTop;

        el.style.cursor = "grabbing";
    }

    function onPointerMove(e) {
        if (!isDragging) return;

        el.style.left = (e.clientX - offsetX) + "px";
        el.style.top = (e.clientY - offsetY) + "px";
    }

    async function onPointerUp(e) {
        if (!isDragging) return;

        isDragging = false;
        isDraggingGlobal = false; // 🔥 unlock

        el.releasePointerCapture(e.pointerId);

        el.style.cursor = "grab";

        await client
            .from("posts")
            .update({
                x: el.offsetLeft,
                y: el.offsetTop
            })
            .eq("id", id);
    }

    el.addEventListener("pointerdown", onPointerDown);
    el.addEventListener("pointermove", onPointerMove);
    el.addEventListener("pointerup", onPointerUp);
    el.addEventListener("pointercancel", onPointerUp);
}

// -------------------------
// REALTIME SYNC
// -------------------------
client
    .channel("posts-channel")
    .on("postgres_changes", (payload) => {
        const event = payload.eventType;
        const row = payload.new;
    
        // 🚫 ignore updates while dragging
        if (isDraggingGlobal) return;
    
        if (event === "INSERT") posts.push(row);
    
        if (event === "UPDATE")
            posts = posts.map(p => p.id === row.id ? row : p);
    
        if (event === "DELETE")
            posts = posts.filter(p => p.id !== payload.old.id);
    
        renderCanvas();
    })
    .subscribe();

// -------------------------
// INIT
// -------------------------
loadPosts();