const SUPABASE_URL = "https://uqcodazkoityuhhnbmum.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_WQwKJgTCh9fTaQV3dNWL-A_LrcipKPi";

const client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let posts = [];
let editorMode = false;

// Editor toggle

function toggleEditorMode() {
    editorMode = !editorMode;
    renderCanvas();
}

function createFinishEditingButton(post) {
    const btn = document.createElement("button");
    btn.innerText = "Finish Editing";
    btn.style.marginTop = "6px";
    btn.style.padding = "4px 6px";
    btn.style.fontSize = "12px";

    btn.onclick = async () => {
        await client
            .from("posts")
            .update({ locked: true })
            .eq("id", post.id);

        post.locked = true;
        renderCanvas();
    };

    return btn;
}
// -------------------------
// RENDER SYSTEM
// -------------------------
function renderCanvas() {
    const canvas = document.getElementById("canvas");
    canvas.innerHTML = "";

    posts.forEach((post) => {
        const wrapper = document.createElement("div");
        wrapper.className = "post";

        wrapper.style.position = "absolute";
        wrapper.style.left = post.x + "px";
        wrapper.style.top = post.y + "px";

        // IMAGE
        const img = document.createElement("img");
        img.src = post.image_url;
        img.style.width = "150px";
        img.style.display = "block";
        img.style.userSelect = "none";
        img.style.cursor = post.locked ? "default" : "grab";

        wrapper.appendChild(img);

        // INFO BOX (ALWAYS EXISTS — CSS controls visibility)
        const info = document.createElement("div");
        info.className = "info";

        // NOTE (optional)
        if (post.note) {
            const note = document.createElement("div");
            note.className = "note";
            note.innerText = "📝 " + post.note;
            info.appendChild(note);

        if (!post.locked && editorMode) {
            const btn = createFinishEditingButton(post);
            info.appendChild(btn);
           
            enableDrag(wrapper, post.id);
            }
        }

        // TIMESTAMP
        const time = document.createElement("div");
        time.className = "time";
        time.innerText = "🕒 " + new Date(post.created_at).toLocaleString();
        info.appendChild(time);

        wrapper.appendChild(info);

        // DRAG ONLY IF EDITABLE
        if (editorMode && !post.locked) {
            enableDrag(wrapper, post.id);
        }

        canvas.appendChild(wrapper);
    });
}
// -------------------------
// LOAD POSTS
// -------------------------
async function loadPosts() {
    const { data, error } = await client
        .from("posts")
        .select("*")
        .order("created_at", { ascending: true });

    if (error) {
        console.log(error);
        return;
    }

    posts = data || [];
    renderCanvas();
}

// -------------------------
// UPLOAD CORE LOGIC
// -------------------------
async function handleUpload(file, x, y) {
    const fileName = `${Date.now()}-${file.name}`;

    await client.storage.from("Images").upload(fileName, file);

    const { data } = client.storage
        .from("Images")
        .getPublicUrl(fileName);

    await client.from("posts").insert([
        {
            image_url: data.publicUrl,
            x,
            y,
            locked: false,
            note: "",
            created_at: new Date().toISOString()
        }
    ]);
}

// -------------------------
// BACKUP FILE INPUT UPLOAD
// -------------------------
window.uploadImage = async function () {
    const file = document.getElementById("fileInput").files[0];
    if (!file) return alert("No file selected");

    await handleUpload(
        file,
        window.innerWidth / 2,
        window.innerHeight / 2
    );
};

// -------------------------
// FULL PAGE DRAG & DROP
// -------------------------
document.addEventListener("dragover", (e) => {
    e.preventDefault();
});

document.addEventListener("drop", async (e) => {
    e.preventDefault();

    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const x = e.clientX;
    const y = e.clientY;

    await handleUpload(file, x, y);
});

// -------------------------
// DRAG MOVEMENT
// -------------------------
function enableDrag(el, id) {
    let offsetX, offsetY, isDragging = false;

    el.addEventListener("mousedown", (e) => {
        isDragging = true;

        offsetX = e.clientX - el.offsetLeft;
        offsetY = e.clientY - el.offsetTop;
    });

    document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;

        el.style.left = (e.clientX - offsetX) + "px";
        el.style.top = (e.clientY - offsetY) + "px";
    });

    document.addEventListener("mouseup", async () => {
        if (!isDragging) return;
        isDragging = false;

        await client
            .from("posts")
            .update({
                x: el.offsetLeft,
                y: el.offsetTop
            })
            .eq("id", id);
    });
}

async function lockPost(id) {
    await client
        .from("posts")
        .update({ locked: true })
        .eq("id", id);

    const post = posts.find(p => p.id === id);
    if (post) post.locked = true;

    renderCanvas();
}

// -------------------------
// REALTIME SYNC
// -------------------------
client
.channel("posts-channel")
.on(
    "postgres_changes",
    {
    event: "*",
    schema: "public",
    table: "posts"
    },
    (payload) => {
    console.log("REALTIME EVENT:", payload);

    const event = payload.eventType;
    const row = payload.new;

    if (event === "INSERT") {
        posts.push(row);
    }

    if (event === "UPDATE") {
        posts = posts.map(p =>
        p.id === row.id ? row : p
        );
    }

    if (event === "DELETE") {
        posts = posts.filter(p => p.id !== payload.old.id);
    }

    renderCanvas();
    }
)
.subscribe((status) => {
    console.log("CHANNEL STATUS:", status);
});

// -------------------------
// INIT
// -------------------------
loadPosts();